package com.example.ltp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
