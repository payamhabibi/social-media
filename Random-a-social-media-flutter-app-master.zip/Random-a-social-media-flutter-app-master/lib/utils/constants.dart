import 'package:flutter/material.dart';

Color ktxtColor = Colors.black;
MaterialColor? kmainColor = Colors.indigo;
const Color kMainColor = Colors.indigo;
Color kaccentColor = Colors.indigoAccent;
Color kbgColor = Colors.white.withOpacity(0.9);
Color kmaintxtColor = Colors.black;
Color ktxtwhiteColor = Colors.white;
