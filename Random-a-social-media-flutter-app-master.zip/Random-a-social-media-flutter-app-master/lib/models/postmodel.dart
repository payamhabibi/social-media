import 'dart:io';

import 'package:ltp/models/usermodel.dart';

class PostModel {
  UserModel user = UserModel(
      name: 'Payam Habibi',
      bio: 'Flutter Developer',
      profileImage:
          'https://images.unsplash.com/photo-1720705816426-42e61c42f777?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwcm9maWxlLXBhZ2V8MXx8fGVufDB8fHx8fA%3D%3D',
      bannerImage:
          'https://c4.wallpaperflare.com/wallpaper/256/820/44/dreams-failure-motivational-inspirational-wallpaper-preview.jpg');
  String tweetText = '';
  File? tweetImage;
  List<String> likes = [];
  List<String> comments = [];
  List<String> retweets = [];
  String? uploadTime;
}
